package upickle
object ScalaVersionStubs{
  type Context = scala.reflect.macros.blackbox.Context
}