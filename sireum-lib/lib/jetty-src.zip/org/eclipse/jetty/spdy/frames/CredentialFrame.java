//
//  ========================================================================
//  Copyright (c) 1995-2014 Mort Bay Consulting Pty. Ltd.
//  ------------------------------------------------------------------------
//  All rights reserved. This program and the accompanying materials
//  are made available under the terms of the Eclipse Public License v1.0
//  and Apache License v2.0 which accompanies this distribution.
//
//      The Eclipse Public License is available at
//      http://www.eclipse.org/legal/epl-v10.html
//
//      The Apache License v2.0 is available at
//      http://www.opensource.org/licenses/apache2.0.php
//
//  You may elect to redistribute this code under either of these licenses.
//  ========================================================================
//

package org.eclipse.jetty.spdy.frames;

import java.security.cert.Certificate;

public class CredentialFrame extends ControlFrame
{
    private final short slot;
    private final byte[] proof;
    private final Certificate[] certificateChain;

    public CredentialFrame(short version, short slot, byte[] proof, Certificate[] certificateChain)
    {
        super(version, ControlFrameType.CREDENTIAL, (byte)0);
        this.slot = slot;
        this.proof = proof;
        this.certificateChain = certificateChain;
    }

    public short getSlot()
    {
        return slot;
    }

    public byte[] getProof()
    {
        return proof;
    }

    public Certificate[] getCertificateChain()
    {
        return certificateChain;
    }
}
