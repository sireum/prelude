package org.scalatest.tools
import javax.swing._
private[tools] class EventHolderJList extends JList