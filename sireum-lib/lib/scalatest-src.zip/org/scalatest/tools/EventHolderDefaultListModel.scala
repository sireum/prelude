package org.scalatest.tools
import javax.swing._
private[tools] class EventHolderDefaultListModel extends DefaultListModel