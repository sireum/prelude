
 package org.scalatest.matchers

 @deprecated("Please use org.scalatest.MustMatchers instead.")
 trait MustMatchers extends org.scalatest.MustMatchers

 @deprecated("Please use org.scalatest.MustMatchers instead.")
 object MustMatchers extends org.scalatest.MustMatchers
    